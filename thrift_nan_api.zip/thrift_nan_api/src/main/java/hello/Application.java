package hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.meituan.service.mobile.message.sinai.ListPoisRequest;
import com.meituan.service.mobile.message.sinai.ListPoisResponse;
import com.meituan.service.mobile.message.sinai.RPCSinaiService;
import com.meituan.mobile.sinai.base.common.PoiFields;
import com.meituan.service.mobile.message.sinai.RequestType;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Application {	
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
package hello;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;

import com.meituan.service.mobile.message.sinai.ListPoisRequest;
import com.meituan.service.mobile.message.sinai.ListPoisResponse;
import com.meituan.service.mobile.message.sinai.RPCSinaiService;
import com.meituan.mobile.sinai.base.common.PoiFields;
import com.meituan.service.mobile.message.sinai.RequestType;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.meituan.service.mobile.search.poi.thrift.MTSearch;
import com.meituan.service.mobile.search.poi.thrift.SearchQueryReq;

import java.util.ArrayList;
import java.util.List;
import com.meituan.service.mobile.message.sinai.PoiField2ValueMap;
import java.util.Iterator;
import java.util.Map;

import utils.requestUtil;
import utils.ResponseCampare;

@RestController
public class GreetingController {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();
    private MTSearch.Iface sphSearchClient;


    @RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="poiid", defaultValue="World") String poiid) {

        ApplicationContext context = new ClassPathXmlApplicationContext(
                "client_config.xml");

        //Staging context, contract with the above
        ApplicationContext context_staging = new ClassPathXmlApplicationContext(
                "client_config_staging.xml");



        ApplicationContext context_test = new ClassPathXmlApplicationContext(
                "test.xml");

        RPCSinaiService.Iface sinaiClient;
        RPCSinaiService.Iface sinaiClient_staging;


        sinaiClient = (RPCSinaiService.Iface) context.getBean("sinaiClient");
        sinaiClient_staging = (RPCSinaiService.Iface) context_staging.getBean("sinaiClient");


        sphSearchClient = (MTSearch.Iface) context_test.getBean("sphSearchClient");

        SearchQueryReq searchquery = new SearchQueryReq();
        try {
            System.out.println(sphSearchClient.MTSearchDeal(searchquery).toString());
        }
        catch (TException e){
            e.printStackTrace();
        }
        //System.out.println(sphSearchClient.MTSearchDeal(searchquery));

        List<Integer> poiids = new ArrayList<Integer>() {{
            add(Integer.parseInt(poiid));
        }};

        requestUtil request_maker = new requestUtil(poiids,PoiFields.BASIC_FIELDS);


        try {

            ListPoisRequest listPoisRequest = request_maker.requestMake(request_maker.getPois(), request_maker.getFields());
            ListPoisResponse sinaiPoiList = sinaiClient.listPoisByIds(listPoisRequest);
            List<Integer> poiids_staging = new ArrayList<Integer>() {{
                add(52490288);
                add(372213);
            }};

            ListPoisRequest listPoisRequest_staging = request_maker.requestMake(poiids_staging, request_maker.getFields());
            ListPoisResponse sinaiPoiList_staging = sinaiClient_staging.listPoisByIds(listPoisRequest_staging);

            if (sinaiPoiList == null || sinaiPoiList_staging == null){
                System.out.println("sinaiPoiList is NULL");
                return new Greeting(402, "sinaiPoiList is NULL","","","","");
            }



            if (sinaiPoiList.getPois().size() != sinaiPoiList_staging.getPois().size()){
                return new Greeting(402, "Size Differnt","","","","");
            }



            System.out.println(sinaiPoiList.toString());
            System.out.println(sinaiPoiList_staging.toString());
            Iterator<PoiField2ValueMap> iter = sinaiPoiList.getPois().iterator();
            Iterator<PoiField2ValueMap> iter_staging = sinaiPoiList_staging.getPois().iterator();

            while (iter.hasNext()){
                Map<String,String> poimap = iter.next().getPoi();
                Map<String,String> poimap_staging = iter_staging.next().getPoi();

                ResponseCampare comparer = new ResponseCampare();
                Map<String,String> diff_online = comparer.diffonline(poimap,poimap_staging);
                Map<String,String> diff_offsline = comparer.diffoffline(poimap, poimap_staging);
                Map<String,String> online_only = comparer.onlineonly(poimap, poimap_staging);
                Map<String,String> offline_only = comparer.offlineonly(poimap, poimap_staging);

                //System.out.println(diff.toString());
                System.out.println(online_only.toString());
                System.out.println(offline_only.toString());
                return new Greeting(200, "ok",diff_online.toString(),diff_offsline.toString(),online_only.toString(),offline_only.toString());

            }



            return new Greeting(201, sinaiPoiList.getPois().toString(),"","","","");

        }  catch (TException e) {
            e.printStackTrace();
        }

        return new Greeting(100,
                "Default","","","","");
    }


}



package hello;

public class Greeting {

    private final long status;
    private final String content;
    private final String value_diff_onlie;
    private final String value_diff_offlie;
    private final String online_only;
    private final String offline_only;
    public Greeting(long status, String content,String value_diff_onlie,String value_diff_offlie,String online_only,String offline_only) {
        this.status = status;
        this.content = content;
        this.value_diff_onlie = value_diff_onlie;
        this.value_diff_offlie = value_diff_offlie;
        this.online_only = online_only;
        this.offline_only = offline_only;
    }

    public long getStatus() {
        return status;
    }

    public String getContent() {
        return content;
    }


    public String getValueDiffOnlie() {
        return this.value_diff_onlie;
    }

    public String getValueDiffOffline() {
        return this.value_diff_offlie;
    }

    public String getOnlineOnly(){
        return this.online_only;
    }

    public String getOfflineOnly() {
        return this.offline_only;
    }
}
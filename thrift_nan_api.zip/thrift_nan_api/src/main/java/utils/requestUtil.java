package utils;

import com.meituan.mobile.sinai.base.common.PoiFields;
import com.meituan.service.mobile.message.sinai.ListPoisRequest;
import com.meituan.service.mobile.message.sinai.RequestType;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by wanghuifang on 16/5/31.
 */
public class requestUtil {
    private List<Integer> poiids;
    private List<String> fields;
    private ListPoisRequest listPoisRequest;

    public requestUtil(List<Integer> poiids, List<String> fields) {
        if (!setPois(poiids)) {
            System.out.println("Poiids can not be null");
        }

        if (!setFields(fields)) {
            System.out.println("Fields can not be null");

        }

        listPoisRequest = new ListPoisRequest();

    }

    public List<Integer> getPois() {
        return this.poiids;
    }

    public List<String> getFields() {
        return this.fields;
    }

    private boolean setPois(List<Integer> poiids) {
        if (poiids == null) {
            return false;
        } else {
            this.poiids = poiids;
            return true;
        }

    }

    private boolean setFields(List<String> fields) {
        if (fields == null) {
            return false;
        } else {
            this.fields = fields;
            return true;
        }
    }

    public ListPoisRequest requestMake(List<Integer> poiids, List<String> fields) {
        if (poiids == null || fields == null) {
            System.out.println("Request Parameters can not be null");
            return null;
        }
        listPoisRequest.setPoiIds(poiids);
        listPoisRequest.setFields(fields);

        return listPoisRequest;
    }

}


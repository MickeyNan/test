package utils;


import java.util.*;

/**
 * Created by wanghuifang on 16/6/1.
 */
public class ResponseCampare {

    private Map<String,String> onlineresponse;
    private Map<String,String> offlineresponse;

    public Map<String,String> diffonline(Map<String,String> onlineresponse,Map<String,String> offlineresponse){

        Map<String,String> diff_online = new HashMap<String, String>();

        diff_online = func(onlineresponse,offlineresponse,true);

        return diff_online;
    }

    public Map<String,String> diffoffline(Map<String,String> onlineresponse,Map<String,String> offlineresponse){

        Map<String,String> diff_offline = new HashMap<String, String>();

        diff_offline = func(offlineresponse,onlineresponse,true);

        return diff_offline;

    }

    public Map<String,String> onlineonly(Map<String,String> onlineresponse,Map<String,String> offlineresponse){

        Map<String,String> online_only = new HashMap<String, String>();

        online_only = func(onlineresponse,offlineresponse,false);

        return online_only;

    }

    public Map<String,String> offlineonly(Map<String,String> onlineresponse,Map<String,String> offlineresponse){

        Map<String,String> offline_only = new HashMap<String, String>();

        offline_only = func(offlineresponse,onlineresponse,false);

        return offline_only;

    }

    public Map<String,String> func(Map<String,String>response_want,Map<String,String>response_comp,boolean value_or_key){

        Map<String,String> map_key_diff = new HashMap<String,String>();
        Map<String,String> map_value_diff = new HashMap<String,String>();

        Set<String> set = response_want.keySet();

        Iterator<String> iter = set.iterator();

        while (iter.hasNext()){
            String key = iter.next();
            if (!response_comp.containsKey(key)){
                map_key_diff.put(key,response_want.get(key));
            }
            else {
                if(response_comp.get(key) != response_want.get(key)){
                    map_value_diff.put(key,response_want.get(key));
                }
            }

        }

        if(value_or_key)
            return map_value_diff;
        else
            return map_key_diff;

    }

}